const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Treaty = sequelize.define('Treaty', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false
    },
    description: {
        type: DataTypes.TEXT
    },
    type: {
        type: DataTypes.ENUM('multilateral', 'bilateral'),
        allowNull: false
    },
    sign_date: {
        type: DataTypes.DATEONLY
    },
    enforce_date: {
        type: DataTypes.DATEONLY
    },
    status: {
        type: DataTypes.ENUM('active', 'terminated', 'superseded'),
        defaultValue: 'active'
    },
    parties_json: {
        type: DataTypes.JSON, // Stores list of countries/parties
        allowNull: true
    },
    pdf_url: {
        type: DataTypes.STRING
    },
    language: {
        type: DataTypes.STRING,
        defaultValue: 'en' // Primary language of this entry
    }
    // Translations can be handled by separate entries or a more complex relation, 
    // for simplicity we'll assume one entry per language or use fields for translations if needed.
    // Given the request, we will stick to basic fields.
});

module.exports = Treaty;
