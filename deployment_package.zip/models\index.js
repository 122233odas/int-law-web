const sequelize = require('../config/database');
const User = require('./User');
const Treaty = require('./Treaty');
const Term = require('./Term');
const Organization = require('./Organization');
const Case = require('./Case');

// Associations (if any)
// Example: User.hasMany(Post);

const db = {
    sequelize,
    User,
    Treaty,
    Term,
    Organization,
    Case
};

module.exports = db;
