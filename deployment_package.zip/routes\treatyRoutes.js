const express = require('express');
const router = express.Router();
const treatyController = require('../controllers/treatyController');

router.get('/', treatyController.getAllTreaties);
router.get('/:id', treatyController.getTreaty);

module.exports = router;
