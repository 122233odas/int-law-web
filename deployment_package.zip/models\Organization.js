const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Organization = sequelize.define('Organization', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    acronym: {
        type: DataTypes.STRING
    },
    founded_year: {
        type: DataTypes.INTEGER
    },
    type: {
        type: DataTypes.ENUM('universal', 'regional', 'specialized')
    },
    description: {
        type: DataTypes.TEXT
    },
    members_json: {
        type: DataTypes.JSON // List of member countries
    },
    website: {
        type: DataTypes.STRING
    },
    logo_url: {
        type: DataTypes.STRING
    }
});

module.exports = Organization;
