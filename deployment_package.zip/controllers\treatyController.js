const Treaty = require('../models/Treaty');
const { Op } = require('sequelize');

exports.getAllTreaties = async (req, res) => {
    try {
        const { search, type, year } = req.query;
        let where = {};

        if (search) {
            where.title = { [Op.like]: `%${search}%` };
        }
        if (type) {
            where.type = type;
        }
        if (year) {
            where.sign_date = { [Op.startsWith]: year };
        }

        const treaties = await Treaty.findAll({ where });
        res.render('pages/treaties/index', {
            title: 'Treaties',
            treaties,
            filters: { search, type, year }
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
};

exports.getTreaty = async (req, res) => {
    try {
        const treaty = await Treaty.findByPk(req.params.id);
        if (!treaty) {
            return res.status(404).render('pages/404', { title: 'Not Found' });
        }
        res.render('pages/treaties/show', { title: treaty.title, treaty });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
};
