const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Term = sequelize.define('Term', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    term_key: {
        type: DataTypes.STRING, // Unique key to link translations if needed
        allowNull: false
    },
    term: {
        type: DataTypes.STRING,
        allowNull: false
    },
    definition: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    language: {
        type: DataTypes.STRING(2), // 'en', 'fr', 'es'
        allowNull: false
    },
    citations_json: {
        type: DataTypes.JSON
    }
});

module.exports = Term;
