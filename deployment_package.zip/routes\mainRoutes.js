const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    res.render('pages/home', {
        title: res.__('home.welcome'),
        // In a real app, you might fetch featured treaties or news here
    });
});

router.get('/change-lang/:lang', (req, res) => {
    const lang = req.params.lang;
    if (['en', 'es', 'fr'].includes(lang)) {
        res.cookie('lang', lang);
    }
    res.redirect('back');
});

module.exports = router;
