# International Law Application

A professional Node.js/Express application for an International Law Organization.

## Features
- **Treaty Management**: Database of multilateral and bilateral treaties.
- **Multilingual**: Support for English, French, and Spanish.
- **Authentication**: Secure Login/Register with Role-Based Access.
- **Database**: MySQL with Sequelize ORM.
- **Frontend**: Bootstrap 5 + EJS Templates.

## Project Structure
- `/config` - Database and middleware configuration.
- `/controllers` - Logic for handling requests.
- `/models` - Sequelize database models.
- `/routes` - Express route definitions.
- `/views` - EJS HTML templates.
- `/public` - Static assets (CSS, Images).
- `/locales` - i18n translation files.

## Local Installation
1. Install dependencies: `npm install`
2. Create database `international_law_db` in MySQL.
3. Configure `.env` (see below).
4. Run: `npm run dev`

## Deployment to Hostinger (cPanel)

### Option A: Using the ZIP File (Recommended)
1. Login to Hostinger cPanel.
2. Go to **File Manager** -> **public_html**.
3. Create a folder (e.g., `app`).
4. Upload `deployment_package.zip`.
5. Extract the zip file contents into the folder.

### Option B: Setup Node.js App
1. In cPanel, search for **"Setup Node.js App"**.
2. Click **Create Application**.
3. **Application Root**: `public_html/app` (or wherever you extracted files).
4. **Application URL**: `yourdomain.com/app`.
5. **Startup File**: `app.js`.
6. Click **Create**.
7. Once created, click **"Run NPM Install"** button in the dashboard to install dependencies.

### Environment Variables (.env)
Create a `.env` file in the root directory (or edit via cPanel environment variables section):
```
PORT=3000
DB_HOST=localhost
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_NAME=your_db_name
JWT_SECRET=secure_secret_key
SESSION_SECRET=secure_session_key
NODE_ENV=production
```

### Database Setup
1. Create a MySQL Database and User in Hostinger.
2. Import the initial structure (Sequelize will auto-sync tables on first run if configured, or use a migration script).
*Note: The current app uses `sequelize.sync()` in development. For production, ensure tables are created.*
