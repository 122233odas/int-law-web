const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Case = sequelize.define('Case', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false
    },
    court: {
        type: DataTypes.STRING, // ICJ, ECHR, etc.
        allowNull: false
    },
    judgement_date: {
        type: DataTypes.DATEONLY
    },
    parties: {
        type: DataTypes.STRING
    },
    summary: {
        type: DataTypes.TEXT
    },
    full_text_url: {
        type: DataTypes.STRING
    },
    tags_json: {
        type: DataTypes.JSON
    }
});

module.exports = Case;
